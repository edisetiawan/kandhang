<?php include('captcha.php');
captcha::image($_GET['salt']);